/* ============================================ Revision History =============================================
Date		Internal	Description
20181113	CY19R1		Modified query to retrieve FEDERAL_FACILITY_ID from SDWIS State.	
================================================================================================================ */
select DISTINCT trim(tinwsys.NUMBER0) AS WATER_SYSTEM_ID,
      TRIM(TINWSF.ST_ASGN_IDENT_CD) AS STATE_ASSIGNED_FAC_ID,
	  TRIM(TINWSF.EXTERNAL_SYS_NUM) AS FEDERAL_FACILITY_ID,
      TRIM(TINWSF.TYPE_CODE) AS FAC_TYPE_NAME,
      NVL(TRIM(TINWSF.NAME),'No Value From State') AS FAC_NAME,
      NVL(TRIM(TINWSF.LOCAL_NAME),'No Value From State') AS FAC_LOCAL_NAME,
      TRIM(TINWSF.ACTIVITY_STATUS_CD) AS ACTIVITY_STATUS_NAME,
      Tinwsf.Activity_Date AS FAC_ACTIVITY_STATUS_DT,
      TRIM(TINWSF.AVAILABILITY_CODE) AS FAC_AVAILABILITY_NAME,
      TRIM(TINWSF.WATER_TYPE_CODE) AS WATER_SOURCE_TYPE_NAME,
      TINWSF.WATER_TYPE_CODE_DT AS WATER_SOURCE_TYPE_DT,
      CASE 
       when TRIM(TINWSF.TREATMENT_STAT_CD) = 'T' then 'Y'
        when TRIM(TINWSF.TREATMENT_STAT_CD) = 'N' then 'N' 
       END AS TREATMENT_STAT_NAME,
	  'Y'				 AS PRIMARY_ADDRESS_FLG,
      NVL(TRIM(C.ADDR_LINE_ONE_TXT),TRIM(C.ADDR_LINE_TWO_TXT))  AS ADMIN_ADDRESS1,
      TRIM(C.ADDR_LINE_TWO_TXT) AS ADMIN_ADDRESS2,
      TRIM(C.ADDRESS_CITY_NAME) AS ADMIN_CITY_NAME,
      TRIM(C.ADDRESS_STATE_CODE) AS ADMIN_STATE_NAME,
      TRIM(C.ADDRESS_ZIP_CODE) AS ADMIN_ZIP_CD,
      CASE 
        WHEN UPPER(TRIM(TINWSF.TYPE_CODE)) IN (SELECT UPPER(TRIM(TEXT_VALUE)) FROM tinpvals  WHERE CODE_NAME = 'WSFSRCTYPE') THEN 'S'
        WHEN UPPER(TRIM(TINWSF.TYPE_CODE)) = 'TP' THEN 'T'
        ELSE 'O'
      END  AS FACILITY_TYPE
from TINWSYS TINWSYS INNER JOIN TINWSF TINWSF ON TINWSF.TINWSYS_IS_NUMBER = tinwsys.TINWSYS_IS_NUMBER AND TINWSF.TINWSYS_ST_CODE  = tinwsys.TINWSYS_ST_CODE
    left outer join TINWSFC TINWSFC on Tinwsf.Tinwsf_Is_Number = Tinwsfc.Tinwsf_Is_Number AND Tinwsf.Tinwsf_St_Code = Tinwsfc.Tinwsf_St_Code and tinwsfc.active_ind_cd = 'A'
    LEFT OUTER JOIN TINLGENT C ON Tinwsfc.Tinlgent_Is_Number = C.Tinlgent_Is_Number AND Tinwsfc.Tinlgent_St_Code = C.Tinlgent_St_Code
	  where (TINWSF.D_LAST_UPDT_TS > 'lastSyncDate' or C.D_LAST_UPDT_TS > 'lastSyncDate' )