SELECT DISTINCT 
      a.TSALAB_ST_CODE AS PRIMACY_AGENCY_CD,
      UPPER(LTRIM(RTRIM(c.name))) AS ORGANIZATION_NM,
	  'L'                 AS categoryName,
      'A'                 AS statusName,
	  UPPER(LTRIM(RTRIM(a.cert_agency)))		  AS CERT_AGENCY,
      a.D_LAST_UPDT_TS   AS MODIFIED_DT,
      a.D_USERID_CODE    AS MODIFIED_USER_ID,
      GETDATE()            AS CREATE_DT,
      a.D_INITIAL_USERID AS CREATE_USER_ID,
      LTRIM(RTRIM(a.LAB_ID_NUMBER))    AS LAB_ID,
	  'Y'				 AS PRIMARY_ADDRESS_FLG,
	  (CASE
        WHEN ( UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE))) <> a.TSALAB_ST_CODE AND upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NOT NULL AND upper(LTRIM(RTRIM(C.COUNTRY_CODE))) <> 'US')
        THEN 'Y'
        ELSE 'N'
      END) AS INTERNATIONAL_FLG,
      ISNULL(nullif(LTRIM(RTRIM(C.ADDR_LINE_ONE_TXT)),''),nullif(LTRIM(RTRIM(C.ADDR_LINE_TWO_TXT)),''))  AS ADMIN_ADDRESS1,
      (CASE
        WHEN upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NULL OR upper(LTRIM(RTRIM(C.COUNTRY_CODE))) = 'US'
        THEN LTRIM(RTRIM(C.ADDR_LINE_TWO_TXT)) 
		ELSE NULL
	   END)	AS ADMIN_ADDRESS2,
      (CASE
        WHEN upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NULL OR upper(LTRIM(RTRIM(C.COUNTRY_CODE))) = 'US'
        THEN LTRIM(RTRIM(C.ADDRESS_CITY_NAME))
		ELSE NULL
	   END) AS ADMIN_CITY_NAME,
	  (CASE
        WHEN upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NULL OR upper(LTRIM(RTRIM(C.COUNTRY_CODE))) = 'US'
        THEN LTRIM(RTRIM(C.ADDRESS_STATE_CODE)) 
		ELSE NULL
	   END) AS ADMIN_STATE_NAME,
	  (CASE
        WHEN upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NULL OR upper(LTRIM(RTRIM(C.COUNTRY_CODE))) = 'US'
        THEN LTRIM(RTRIM(C.ADDRESS_ZIP_CODE)) 
		ELSE NULL
	   END) AS ADMIN_ZIP_CD,
	  (select D.Electronic_Address from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'EMAIL' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'EMAIL')) as AC_Email_Address,
      (select D.Phone_number from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'BUS' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'BUS')) as B_Phone_number,
      (select D.Phone_number from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'EMERG' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'EMERG')) as E_Phone_number,
       (select D.Phone_number from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'HOME' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'HOME')) as H_Phone_number,
       (select D.Phone_number from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'MOB' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'MOB')) as M_Phone_number,
       (select D.Phone_number from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'FAX' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'FAX')) as Fax_number,
       (select D.Electronic_Address from TINLGCOM D where c.tinlgent_is_number = D.tinlgent_is_number and Upper(LTRIM(RTRIM(D.purpose_code))) = 'URL' and D.tinlgcom_is_number = (select max(Y.Tinlgcom_Is_Number) from tinlgcom Y where D.Tinlgent_Is_Number = Y.tinlgent_is_number and Upper(LTRIM(RTRIM(Y.purpose_code))) = 'URL')) as AC_URL_Address,
	   (CASE
        WHEN ( UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE))) <> a.TSALAB_ST_CODE AND upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NOT NULL AND upper(LTRIM(RTRIM(C.COUNTRY_CODE))) <> 'US')
        THEN UPPER(LTRIM(RTRIM(C.ADDRESS_CITY_NAME)))
        ELSE NULL
      END) AS INTERNATIONAL_CITY,
      (CASE
        WHEN ( UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE))) <> a.TSALAB_ST_CODE AND upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NOT NULL AND upper(LTRIM(RTRIM(C.COUNTRY_CODE))) <> 'US')
        THEN UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE)))
        ELSE NULL
      END) AS INTERNATIONAL_PROV,
      (
      CASE
        WHEN ( UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE))) <> a.TSALAB_ST_CODE AND upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NOT NULL AND upper(LTRIM(RTRIM(C.COUNTRY_CODE))) <> 'US')
        THEN UPPER(LTRIM(RTRIM(C.COUNTRY_CODE)))
        ELSE NULL
      END) AS INTERNATIONAL_COUNTRY_NAME,
      (
      CASE
        WHEN ( UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE))) <> a.TSALAB_ST_CODE AND upper(nullif(LTRIM(RTRIM(C.COUNTRY_CODE)),'')) IS NOT NULL AND upper(LTRIM(RTRIM(C.COUNTRY_CODE))) <> 'US')
        THEN LTRIM(RTRIM(C.INT_POST_CD))
        ELSE NULL
      END) AS INTERNATIONAL_POSTAL_CD
    FROM TSALAB a LEFT OUTER JOIN TSALLEA b ON A.TSALAB_IS_NUMBER = B.TSALAB0IS_NUMBER AND A.TSALAB_ST_CODE = B.TSALAB0ST_CODE
   LEFT OUTER join TINLGENT c ON B.TINLGENT0IS_NUMBER = C.TINLGENT_IS_NUMBER AND B.TINLGENT0ST_CODE  = C.TINLGENT_ST_CODE
   -- and ISNULL(nullif(LTRIM(RTRIM(C.ADDR_LINE_ONE_TXT)),''),nullif(LTRIM(RTRIM(C.ADDR_LINE_TWO_TXT)),'')) is not null
      -- and nullif(LTRIM(RTRIM(C.ADDRESS_CITY_NAME)),'') is not null
      -- and nullif(LTRIM(RTRIM(C.ADDRESS_STATE_CODE)),'') is not null
	  -- and nullif(LTRIM(RTRIM(C.ADDRESS_ZIP_CODE)),'') is not null
   WHERE B.ACTIVE_IND_CODE = 'A' 
   AND B.TYPE_CODE = 'AC'
   and (a.D_LAST_UPDT_TS > 'lastSyncDate' or c.D_LAST_UPDT_TS > 'lastSyncDate' )