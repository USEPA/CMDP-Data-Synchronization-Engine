/* ============================================ Revision History =============================================
Date		Internal	Description
20181213	CY19R1		Modified query to retrieve FEDERAL_FACILITY_ID from SDWIS State.	
================================================================================================================ */
SELECT LTRIM(RTRIM(Tinwsys.Number0)) AS waterSystemId, 
      LTRIM(RTRIM(TINWSF.ST_ASGN_IDENT_CD)) AS facilityName,
	  LTRIM(RTRIM(TINWSF.EXTERNAL_SYS_NUM)) AS FEDERAL_FACILITY_ID,
      LTRIM(RTRIM(TSASMPPT.IDENTIFICATION_CD)) AS samplingPointId,
      LTRIM(RTRIM(TSASMPPT.DESCRIPTION_TEXT))  AS samplingPointNm,
      TSASMPPT.ACTIVITY_DATE     AS smpPntActivityStatusDt,
      upper(LTRIM(RTRIM(TSASMPPT.SOURCE_TYPE_CODE))) AS smpPntWatertreatStatName,
      upper(LTRIM(RTRIM(TSASMPPT.ACTIVITY_STATUS_CD))) AS smpPntActivityStatusName,
      upper(LTRIM(RTRIM(TSASMPPT.TYPE_CODE))) AS smpPntTypeRefName,
      'NOTE1: '
      + LTRIM(RTRIM(note_1))
      + '  NOTE2: '
      + LTRIM(RTRIM(note_2))
      + '  NOTE3: '
      + LTRIM(RTRIM(note_3))  AS COMMENTS,
      TSASMPPT.D_LAST_UPDT_TS   AS MODIFIED_DT,
      TSASMPPT.D_USERID_CODE    AS MODIFIED_USER_ID,
      TSASMPPT.D_INITIAL_TS     AS CREATE_DT,
      TSASMPPT.D_INITIAL_USERID AS CREATE_USER_ID
    FROM TSASMPPT TSASMPPT INNER JOIN TINWSF TINWSF ON TSASMPPT.tinwsf0is_number = TINWSF.tinwsf_is_number and Tsasmppt.Tinwsf0st_Code = Tinwsf.Tinwsf_St_Code
    INNER JOIN TINWSYS TINWSYS ON Tinwsf.Tinwsys_Is_Number = Tinwsys.Tinwsys_Is_Number AND Tinwsf.Tinwsys_St_Code = Tinwsys.Tinwsys_St_Code
    WHERE TSASMPPT.D_LAST_UPDT_TS > 'lastSyncDate'