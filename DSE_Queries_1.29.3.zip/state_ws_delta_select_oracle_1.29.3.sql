/* ============================================ Revision History =============================================
Date		Internal	Description
20180920	CY19R5		Modified query to retrieve Distinct records from subqueries.
20200109    1.21        Modified query to select NULL for COMMENTS
================================================================================================================ */ 
select trim(a.NUMBER0) AS WATER_SYSTEM_ID,
       trim(a.NAME)             AS WS_NM,
       trim(a.ALTERNATE_ST_NUM) AS WS_STATE_ID,
       NULL                     AS DECOMMISSION_DT,
       trim(a.LOCAL_NAME)       AS STATE_LOCAL_NM,
       trim(a.STAGE2_CDS_ID)    AS COMBINED_DIST_SYSTEM_ID,
       null AS LONG_TERM2_ESWTR_SCHED_CAT,
       null AS STAGE2_DBPR_SCHED_CAT,
       null AS OUTSTANDING_PERFORMER_FLG,
       null AS OUTSTANDING_PERFORMER_BEGIN_DT,
       null AS STATE_SOURCE_WATER_PROG_FLG,
       null AS STATE_SOURCE_WATER_BEGIN_DT,
       a.GRND_WTR_RATIO     AS GROUNDWATER_NON_PURCH_PC,
       a.GRND_WTR_PUR_RATIO AS GROUNDWATER_PURCH_PC,
       a.GRND_WTR_UDI_RATIO AS GROUNDWATER_UDI_NON_PURCH_PC,
       a.GRND_WTR_UDI_PURCH AS GROUNDWATER_UDI_PURCH_PC,
       a.SURF_WTR_RATIO     AS SURFACE_WATER_NON_PURCH_PC,
       a.SURF_WTR_PUR_RATIO AS SURFACE_WATER_PURCH_PC,
                   D.Avg_Daily_Cnt  AS POPULATION_COUNT,
       TRIM(D.Type_Code) AS POPULATION_TYPE,
       E.Eff_Begin_Dt AS POP_EFFEC_BEGIN_DT,
       E.Eff_End_Dt AS POP_EFFEC_END_DT,
                   E.Start_Month||'/'||E.Start_Day AS POP_SERVICE_PD_BEGIN_DT,
       E.End_Month||'/'||E.End_Day AS POP_SERVICE_PD_END_DT,
                   NVL(upper(trim(a.PWS_ST_TYPE_CD)),upper(trim(a.D_PWS_FED_TYPE_CD))) AS WS_STATE_TYPE_NAME,
                   upper(TRIM(a.D_FED_PRIM_SRC_CD)) AS WS_FED_WATER_SRC_TYPE_NAME,
      trim(a.owner_type_code) AS  WS_OWNER_TYPE_NAME,
       a.activity_status_cd AS WS_ACTIVITY_STATUS_NAME,
       a.ACTIVITY_DATE AS WS_ACTIVITY_START_DT,
                   NVL(upper(TRIM(a.D_ST_PRIM_SRC_CD)),upper(TRIM(a.D_FED_PRIM_SRC_CD))) AS WS_STATE_WATER_SRC_TYPE_NAME,
     UPPER(TRIM(f.first_name_text)) as ADMIN_FIRST_NAME,
     Upper(trim(f.last_name)) as ADMIN_LAST_NAME,
     B.BEGIN_DATE as ADMIN_CONTACT_START_DATE,
                   'Y'                                                         AS PRIMARY_ADDRESS_FLG,
       UPPER(NVL(TRIM(C.ADDR_LINE_ONE_TXT),TRIM(C.ADDR_LINE_TWO_TXT))) AS ADMIN_CONTACT_ADDRESS1_NAME,
       UPPER(TRIM(C.ADDR_LINE_TWO_TXT)) AS ADMIN_CONTACT_ADDRESS2_NAME,
       UPPER(TRIM(C.ADDRESS_CITY_NAME)) AS ADMIN_CONTACT_CITY_NAME,
       UPPER(TRIM(C.ADDRESS_STATE_CODE)) AS ADMIN_CONTACT_STATE_NAME,
       TRIM(C.ADDRESS_ZIP_CODE) AS ADMIN_CONTACT_ZIP_NAME,
       NULL                      AS COMMENTS,
       1                         AS VERSION,
       SYSDATE                   AS CREATE_DT,
       a.D_INITIAL_USERID        AS CREATE_USER_ID,
       a.D_LAST_UPDT_TS          AS MODIFIED_DT,
       a.D_USERID_CODE           AS MODIFIED_USER_ID,
       (SELECT D_LAST_UPDT_TS
        FROM TINWASH TINWASH
        WHERE tinwash_is_number  = a.tinwsys_is_number
              AND a.ACTIVITY_STATUS_CD = 'D'
       ) AS REMOVE_DT,
       A.TINWSYS_ST_CODE||'_MIGRATOR' AS REMOVE_USER_ID,
       NULL          AS WATER_PERCENT_COMMENT
from TINWSYS A left outer join TINWSLEC B ON A.Tinwsys_Is_Number = B.Tinwsys_Is_Number AND A.Tinwsys_St_Code = B.Tinwsys_St_Code 
      AND B.Type_Code = 'AC' AND B.Active_Ind_Cd = 'A'
      LEFT OUTER JOIN TINLGENT C ON B.Tinlgent_Is_Number = C.Tinlgent_Is_Number AND B.Tinlgent_St_Code = C.Tinlgent_St_Code
      and NVL(TRIM(C.ADDR_LINE_ONE_TXT),TRIM(C.ADDR_LINE_TWO_TXT)) is not null
      and TRIM(C.ADDRESS_CITY_NAME) is not null
      and TRIM(C.ADDRESS_STATE_CODE) is not null
	  and TRIM(C.ADDRESS_ZIP_CODE) is not null		  
      left outer join TININDIV F on C.Tinlgent_Is_Number = F.Tinlgent_Is_Number and C.Tinlgent_St_Code = F.Tinlgent_St_Code and C.Type_Code = 'IN'
      LEFT OUTER JOIN TINAOPRD E ON A.Tinwsys_Is_Number = E.Tinwsys_Is_Number AND A.Tinwsys_St_Code = E.Tinwsys_St_Code and E.Eff_End_Dt is null
      LEFT OUTER JOIN TINPOPSV D ON D.Tinaoprd_Is_Number = E.Tinaoprd_Is_Number
      where TRIM(A.Activity_Status_Cd) IN ('A','I','P')
      AND (a.D_LAST_UPDT_TS > 'lastSyncDate' or c.D_LAST_UPDT_TS > 'lastSyncDate' OR D.D_LAST_UPDT_TS > 'lastSyncDate' OR E.D_LAST_UPDT_TS > 'lastSyncDate' OR F.D_LAST_UPDT_TS > 'lastSyncDate')
