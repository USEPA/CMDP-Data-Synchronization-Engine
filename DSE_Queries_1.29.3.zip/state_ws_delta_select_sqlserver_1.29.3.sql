/* ============================================ Revision History =============================================
Date		Internal	Description
20180920	CY19R5		Modified query to retrieve Distinct records from subqueries.
20191115	1.19		Modified query to make it compatible with older SQL Server version and resolve NULL update issue in Data and Time field.
20200109    1.21        Modified query to select NULL for COMMENTS
================================================================================================================ */ 
SELECT
  LTRIM(RTRIM(a.NUMBER0))                                         AS WATER_SYSTEM_ID,
  LTRIM(RTRIM(a.NAME))                                                                AS WS_NM,
  LTRIM(RTRIM(a.ALTERNATE_ST_NUM))                                                    AS WS_STATE_ID,
  cast(null as datetime)                                                              AS DECOMMISSION_DT,
  LTRIM(RTRIM(a.LOCAL_NAME))                                                          AS STATE_LOCAL_NM,
  LTRIM(RTRIM(a.STAGE2_CDS_ID))                                                       AS COMBINED_DIST_SYSTEM_ID,
  NULL                                                                                AS LONG_TERM2_ESWTR_SCHED_CAT,
  NULL                                                                                AS STAGE2_DBPR_SCHED_CAT,
  NULL                                                                                AS OUTSTANDING_PERFORMER_FLG,
  cast(null as datetime)                                                              AS OUTSTANDING_PERFORMER_BEGIN_DT,
  NULL                                                                                AS STATE_SOURCE_WATER_PROG_FLG,
  cast(null as datetime)                                                              AS STATE_SOURCE_WATER_BEGIN_DT,
  a.GRND_WTR_RATIO                                                                    AS GROUNDWATER_NON_PURCH_PC,
  a.GRND_WTR_PUR_RATIO                                                                AS GROUNDWATER_PURCH_PC,
  a.GRND_WTR_UDI_RATIO                                                                AS GROUNDWATER_UDI_NON_PURCH_PC,
  a.GRND_WTR_UDI_PURCH                                                                AS GROUNDWATER_UDI_PURCH_PC,
  a.SURF_WTR_RATIO                                                                    AS SURFACE_WATER_NON_PURCH_PC,
  a.SURF_WTR_PUR_RATIO                                                                AS SURFACE_WATER_PURCH_PC,
  D.Avg_Daily_Cnt                                                                     AS POPULATION_COUNT,
  LTRIM(RTRIM(D.Type_Code))                                                           AS POPULATION_TYPE,
  E.Eff_Begin_Dt                                                                      AS POP_EFFEC_BEGIN_DT,
  E.Eff_End_Dt                                                                        AS POP_EFFEC_END_DT,
  cast(E.Start_Month AS VARCHAR(2)) + '/' + cast(E.Start_Day AS VARCHAR(2))           AS POP_SERVICE_PD_BEGIN_DT,
  cast(E.End_Month AS VARCHAR(2)) + '/' + cast(E.End_Day AS VARCHAR(2))               AS POP_SERVICE_PD_END_DT,
  ISNULL(upper(NULLIF(LTRIM(RTRIM(a.PWS_ST_TYPE_CD)),'')), upper(NULLIF(LTRIM(RTRIM(a.D_PWS_FED_TYPE_CD)),'')))     AS WS_STATE_TYPE_NAME,
  UPPER(LTRIM(RTRIM(a.D_FED_PRIM_SRC_CD)))				                              AS WS_FED_WATER_SRC_TYPE_NAME,
  LTRIM(RTRIM(a.owner_type_code))			                                          AS WS_OWNER_TYPE_NAME,
  a.activity_status_cd                                                                AS WS_ACTIVITY_STATUS_NAME,
  a.ACTIVITY_DATE                                                                     AS WS_ACTIVITY_START_DT,
  ISNULL(upper(NULLIF(LTRIM(RTRIM(a.D_ST_PRIM_SRC_CD)),'')), upper(NULLIF(LTRIM(RTRIM(a.D_FED_PRIM_SRC_CD)),'')))    AS WS_STATE_WATER_SRC_TYPE_NAME,
  UPPER(LTRIM(RTRIM(f.first_name_text)))                                              AS ADMIN_FIRST_NAME,
  UPPER(LTRIM(RTRIM(f.last_name)))                                                    AS ADMIN_LAST_NAME,
  B.BEGIN_DATE                                                                        AS ADMIN_CONTACT_START_DATE,
  'Y'                                                                                 AS PRIMARY_ADDRESS_FLG,
  UPPER(ISNULL(NULLIF(LTRIM(RTRIM(C.ADDR_LINE_ONE_TXT)),''), NULLIF(LTRIM(RTRIM(C.ADDR_LINE_TWO_TXT)),''))) AS ADMIN_CONTACT_ADDRESS1_NAME,
  UPPER(LTRIM(RTRIM(C.ADDR_LINE_TWO_TXT)))                                            AS ADMIN_CONTACT_ADDRESS2_NAME,
  UPPER(LTRIM(RTRIM(C.ADDRESS_CITY_NAME)))                                            AS ADMIN_CONTACT_CITY_NAME,
  UPPER(LTRIM(RTRIM(C.ADDRESS_STATE_CODE)))                                           AS ADMIN_CONTACT_STATE_NAME,
  LTRIM(RTRIM(C.ADDRESS_ZIP_CODE))                                                    AS ADMIN_CONTACT_ZIP_NAME,
  NULL                                                                                AS COMMENTS,
  1                                                                                   AS VERSION,
  GETDATE()                                                                           AS CREATE_DT,
  a.D_INITIAL_USERID                                                                  AS CREATE_USER_ID,
  a.D_LAST_UPDT_TS                                                                    AS MODIFIED_DT,
  a.D_USERID_CODE                                                                     AS MODIFIED_USER_ID,
  (SELECT D_LAST_UPDT_TS
   FROM TINWASH TINWASH
   WHERE tinwash_is_number = a.tinwsys_is_number
         AND a.ACTIVITY_STATUS_CD = 'D'
  )                                                                                   AS REMOVE_DT,
  A.TINWSYS_ST_CODE + '_MIGRATOR'                                                     AS REMOVE_USER_ID,
  NULL                                                                                AS WATER_PERCENT_COMMENT
FROM TINWSYS A LEFT OUTER JOIN TINWSLEC B
    ON A.Tinwsys_Is_Number = B.Tinwsys_Is_Number AND A.Tinwsys_St_Code = B.Tinwsys_St_Code
       AND B.Type_Code = 'AC' AND B.Active_Ind_Cd = 'A'
  LEFT OUTER JOIN TINLGENT C ON B.Tinlgent_Is_Number = C.Tinlgent_Is_Number AND B.Tinlgent_St_Code = C.Tinlgent_St_Code
                                AND ISNULL(NULLIF(LTRIM(RTRIM(C.ADDR_LINE_ONE_TXT)),''), NULLIF(LTRIM(RTRIM(C.ADDR_LINE_TWO_TXT)),'')) IS NOT NULL
                                AND NULLIF(LTRIM(RTRIM(C.ADDRESS_CITY_NAME)),'') IS NOT NULL
                                AND NULLIF(LTRIM(RTRIM(C.ADDRESS_STATE_CODE)),'') IS NOT NULL
								AND NULLIF(LTRIM(RTRIM(C.ADDRESS_ZIP_CODE)),'') IS NOT NULL
  LEFT OUTER JOIN TININDIV F on C.Tinlgent_Is_Number = F.Tinlgent_Is_Number and C.Tinlgent_St_Code = F.Tinlgent_St_Code and C.Type_Code = 'IN'
  LEFT OUTER JOIN TINAOPRD E ON A.Tinwsys_Is_Number = E.Tinwsys_Is_Number AND A.Tinwsys_St_Code = E.Tinwsys_St_Code and E.Eff_End_Dt is null
  LEFT OUTER JOIN TINPOPSV D ON D.Tinaoprd_Is_Number = E.Tinaoprd_Is_Number
WHERE LTRIM(RTRIM(A.Activity_Status_Cd)) IN ('A','I','P')
AND (a.D_LAST_UPDT_TS > 'lastSyncDate' OR c.D_LAST_UPDT_TS > 'lastSyncDate' OR D.D_LAST_UPDT_TS > 'lastSyncDate' OR
       E.D_LAST_UPDT_TS > 'lastSyncDate' OR F.D_LAST_UPDT_TS > 'lastSyncDate')